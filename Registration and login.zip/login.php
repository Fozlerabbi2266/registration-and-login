<?php
$db = mysqli_connect('localhost', 'root', '', 'php');

if (isset($_POST['email']) and isset($_POST['password'])){

// Assigning POST values to variables.
$email = $_POST['email'];
$password = $_POST['password'];

// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM users WHERE email='$email' and password='$password'";

$result = mysqli_query($db, $query) or die(mysqli_error($db));
$count = mysqli_num_rows($result);

if ($count == 1){
header('location: dashboard.php');

}else{
echo "<script type='text/javascript'>alert('Login failed')</script>";
//echo "Invalid Login Credentials";
}
}

?>
<!DOCTYPE html>

<html >
  <head>
      <link rel="stylesheet" type="text/css" href="login.css">

  </head>
  <body>
    <div class="login">
    <div class="form">
      <form class="Register-form" method="POST" >
          <input type="email" name="email" placeholder="Email Id"/>
        <input type="password" name="password" placeholder="Password"/>

        <input type="submit" name="submit" value="Log in">
        <p class="masage"> Not Registered ? <a href="Registration.php"> Registration </a></p>
      </form>

    </div>

      </div>
  </body>
</html>
