<?php
include ('server.php') ?>
<!DOCTYPE html>
<!DOCTYPE html>
<html >
<head>
  <link rel="stylesheet" href="registration.css">
</head>
<body>
  <header>
    <div class="regform">
    <h1>Registration from</h1><br><br>
    </div>
  </header>
<div class="main">
  <form method="POST" action="#" >
    <div id="name">
  <h2 class="name"></h2>
  <label class="nl">Name</label><br>
  <input class="firstname"type="text" name="firstname"><br>
  <label class="firstlabel">First Name</label><br>
  <input class="lastname"type="text" name="lastname">
  <label class="lastlabel">Last Name</label>
</div><br><br>
<label class="ell">Email</label>
  <h2></h2>
<input class="email" type="email" name="email">


  <label class="pl">Password</label>
  <h2 class="name"></h2>
  <input class="password"type="password" name="password">

    <label class="ml">Mobile No</label>
  <h2 class="name"></h2>
  <input class="mobile" type="text" name="mobile">

  <label class="al">Address</label>
  <h2 class="name"></h2>
  <input class="address"type="text" name="address">
 <div class="city">
<select class="city" name="city">
  <option value="Dhaka">Dhaka</option>
  <option value="Rajshahi">Rajshahi</option>
  <option value="Rangpur">Rangpur</option>
  <option value="Sylhet">Sylhet</option>
  <option value="Mymensingh">Mymensingh </option>
  <option value="Khulna">Khulna </option>
  <option value="Barisal">Barisal</option>
  <option value="Chittagong">Chittagong</option>
</select>
<label class="scity">Select city</label>
</div><br>
<input type="submit" class="b" name="reg" value="Register">

  </form>
</div>
</body>
</html>
